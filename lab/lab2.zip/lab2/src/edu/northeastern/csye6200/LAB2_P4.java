package edu.northeastern.csye6200;

public class LAB2_P4 {
	public static void main(String[] args){
		// TODO: write your code here
	}
}
