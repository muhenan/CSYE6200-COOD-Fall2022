package edu.northeastern.csye6200;

public class LAB2_P3 {
	public static void main(String[] args){
		// TODO: write your code here
	}
}
